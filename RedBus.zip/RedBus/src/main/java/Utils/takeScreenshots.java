package Utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import SeleniumFunctions.readBrowserDriver;

public class takeScreenshots {

	public static void takeUIScreenshot() throws IOException
	{
		
		TakesScreenshot sc = (TakesScreenshot)readBrowserDriver.driver;
		File file = sc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("D:\\eclipse\\RedBus\\screenshot\\alert.png"));
	}
	
}
