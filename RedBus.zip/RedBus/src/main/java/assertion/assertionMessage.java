package assertion;

public interface assertionMessage {

       public static String altermessage = "Do you really want";
}
