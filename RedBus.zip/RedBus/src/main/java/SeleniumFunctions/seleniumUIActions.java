package SeleniumFunctions;

import java.io.IOException;

import org.openqa.selenium.By;

import Configurations.ReusableData;
import excel.readDataFromExcel;

public class seleniumUIActions {
	
	public static void enterVlues() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchexcelData(1, 1));
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.lastName.input"))).sendKeys(readDataFromExcel.fetchexcelData(1, 2));
	
	}

	
}
