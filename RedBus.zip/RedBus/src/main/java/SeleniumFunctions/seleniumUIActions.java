package SeleniumFunctions;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import Configurations.ReusableData;
import assertion.assertionMessage;
import excel.readDataFromExcel;

public class seleniumUIActions {
	
	public static void enterVlues() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 1));
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.lastName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 2));
	
	}

	public static void clickHomes() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.HomePage.a"))).click();
		
	
	}
	
	public static void selectdropdown() throws IOException
	{
		
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.MailingInfo.Country.select")));
		Select sel = new Select(ele);
		sel.selectByValue("ALGERIA");
		
	
	}
	
	public static void handleAlert() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
		Alert obj = readBrowserDriver.driver.switchTo().alert();
		String msg1 = obj.getText();
		System.out.println(msg1);
//		Assert.assertEquals(msg1, assertionMessage.altermessage);
		SoftAssert soft = new SoftAssert();
		soft.assertEquals(msg1, assertionMessage.altermessage);
		obj.accept();
//		String msg = obj.getText();
//		System.out.println(msg);
//		//obj.dismiss();
		
	
	}
	
	public static void handlewait()
	{
		//hard code wait or implicit wait
		//explicit wait
		//fluent wait
		
//		readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
//		try {
//			readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
//			
//		} catch (NoSuchElementException e) {
//			readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
//			readBrowserDriver.driver.findElement(By.xpath("(//input[@id='txt1'])[1]")).click();
//		}
		try
		{
			readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
			WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt1'])[1]")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt1'])[2]")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt1'])[3]")));
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	public static void switchtowondow() throws InterruptedException
	{
    
	}
	
	public static void switchtoframe() throws InterruptedException
	{
		readBrowserDriver.driver.switchTo().frame("a077aa5e");
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath("//a[@href='http://www.guru99.com/live-selenium-project.html']"));
		
		JavascriptExecutor js = (JavascriptExecutor)readBrowserDriver.driver;
		js.executeScript("arguments[0].click", ele);
		
	}
	
	public static void webtable() throws InterruptedException
	{
		
		
		List<WebElement> list =readBrowserDriver.driver.findElements(By.xpath("//table[@class='dataTable']//tbody//tr"));
		System.out.println(list.size());
		for (int i = 1; i < list.size(); i++) {	
		List<WebElement> columsize = readBrowserDriver.driver.findElements(By.xpath("//table[@class='dataTable']//tbody//tr["+i+"]//td"));
		for (int j = 1; j < columsize.size(); j++) {
			WebElement ele =readBrowserDriver.driver.findElement(By.xpath("//table[@class='dataTable']//tbody//tr["+i+"]//td["+j+"]"));
			System.out.println("Element [" + i + "][" + j + "]: " + ele.getText());
		}	
			

		}
		
	}
		public static void actionclass() throws InterruptedException
		{
			WebElement ele = readBrowserDriver.driver.findElement(By.xpath("//button[@id='developers-dd-toggle']"));
			Actions act = new Actions(readBrowserDriver.driver);
			act.moveToElement(ele).build().perform();
			readBrowserDriver.driver.findElement(By.xpath("//span[text()='Documentation']")).click();

			
	}
	
		
		public static void waitInselenium() throws InterruptedException
		{
			

			
	}
	
	
}
