package SeleniumFunctions;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Configurations.ReusableData;
import excel.readDataFromExcel;

public class seleniumUIActions {
	
	public static void enterVlues() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 1));
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.lastName.input"))).sendKeys(readDataFromExcel.fetchexcelData(0, 2));
	
	}

	public static void clickHomes() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.HomePage.a"))).click();
		
	
	}
	
	public static void selectdropdown() throws IOException
	{
		
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.MailingInfo.Country.select")));
		Select sel = new Select(ele);
		sel.selectByValue("ALGERIA");
		
	
	}
	
}
