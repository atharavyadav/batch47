package SeleniumFunctions;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import Configurations.ReusableData;

public class readdatafromfile {

	
	public static String readdatafromOR(String key) throws IOException {
		File file = new File(ReusableData.OR_File_Location);
		FileInputStream stream = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(stream);
		String ordata = prop.getProperty(key);
		return ordata;
		
	}
}
