package SeleniumFunctions;
//Author:neelam
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Configurations.ReusableData;

public class readBrowserDriver {
	 public static  WebDriver driver ;
	public static void readbrowser(String path,String browsertype,String url)
	{
		
		System.setProperty(browsertype, path);
		
		if(ReusableData.Env=="QA") {
			driver=new ChromeDriver();
			driver.get(url);
		}
		
		else if(ReusableData.Env=="PROD"){
			driver=new ChromeDriver();
			driver.get(url);
		}
		
	}
	
	public static void maximizeBroser()
	{
		driver.manage().window().maximize();
	}
	
	
}
