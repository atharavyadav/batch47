package SeleniumFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Configurations.ReusableData;

public class readBrowserDriver {
	static WebDriver driver = new ChromeDriver();
	public static void readbrowser(String path,String browsertype)
	{
		
		System.setProperty(browsertype, path);
		
		if(ReusableData.Env=="QA") {
			driver.get(ReusableData.url);
		}
		
		else if(ReusableData.Env=="PROD"){
			driver.get(ReusableData.PROD_url);
		}
		
	}
	
	public static void maximizeBroser()
	{
		driver.manage().window().maximize();
	}
	
	
}
