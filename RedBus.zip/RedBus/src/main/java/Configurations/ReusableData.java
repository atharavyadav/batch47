package Configurations;
//Author:neelam
public interface ReusableData {
	
	public static String browsertype="webdriver.chrome.driver";
	public static String browsertype_edge="webdriver.edge.driver";
	public static String chromedriverpath="D:\\eclipse\\RedBus\\Browser\\chromedriver.exe";
	public static String Edgedriverpath="D:\\eclipse\\RedBus\\Browser\\msedgedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String alerturl="https://demo.guru99.com/test/delete_customer.php";
	public static String Env="QA";
	public static String webtable="https://demo.guru99.com/test/web-table-element.php";
	public static String HeadLess_Execution="Yes";
	public static String Cross_Browser_Type="chrome";
	public static String PROD_url="https://www.redbus.com/";
	public static String windowswitch_url="https://demo.guru99.com/test/guru99home/";
	public static String waitUrl_url="https://www.hyrtutorials.com/p/waits-demo.html";
	public static String OR_File_Location="D:\\eclipse\\RedBus\\ObjectProperties\\OR.properties";
	public static String Excel_File_Location="D:\\eclipse\\RedBus\\src\\test\\resources\\testData\\testData.xlsx";

}
