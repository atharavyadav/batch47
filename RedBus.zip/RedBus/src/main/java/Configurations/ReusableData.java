package Configurations;

public interface ReusableData {
	
	public static String browsertype="webdriver.chrome.driver";
	public static String chromedriverpath="D:\\eclipse\\RedBus\\Browser\\chromedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String Env="QA";
	public static String PROD_url="https://www.redbus.com/";
	

}
