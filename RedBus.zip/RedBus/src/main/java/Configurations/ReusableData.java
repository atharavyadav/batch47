package Configurations;
//Author:neelam
public interface ReusableData {
	
	public static String browsertype="webdriver.chrome.driver";
	public static String chromedriverpath="D:\\eclipse\\RedBus\\Browser\\chromedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String alerturl="https://demo.guru99.com/test/delete_customer.php";
	public static String Env="QA";
	public static String PROD_url="https://www.redbus.com/";
	public static String OR_File_Location="D:\\eclipse\\RedBus\\ObjectProperties\\OR.properties";
	public static String Excel_File_Location="D:\\eclipse\\RedBus\\src\\test\\resources\\testData\\testData.xlsx";

}
