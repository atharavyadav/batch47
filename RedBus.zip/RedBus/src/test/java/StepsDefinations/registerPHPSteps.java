package StepsDefinations;

import java.io.IOException;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class registerPHPSteps {

	@Given("Im login to the homepage")
	public void handleWaitMethod() throws IOException, InterruptedException
	{
	
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.url);
		readBrowserDriver.maximizeBroser();
	    
	}
	
	@Then("User clicks on Devloper PAge and MouseHover on element and clicks on Documntaion")
	public void clickonDevlperPage() throws IOException, InterruptedException
	{
	
		seleniumUIActions.actionclass();
	    
	}
	
}
