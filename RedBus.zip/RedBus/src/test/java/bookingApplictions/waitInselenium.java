package bookingApplictions;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class waitInselenium {
	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.ActionCllassurl);
		readBrowserDriver.maximizeBroser();
	}
	@Test(priority = 1)
	public void handleWaitMethod() throws IOException, InterruptedException
	{
	
		seleniumUIActions.actionclass();
	    
	}
	
	@AfterMethod
	public void closebrowser() throws IOException, InterruptedException
	{
	
    
//  readBrowserDriver.driver.close();
	}
}
