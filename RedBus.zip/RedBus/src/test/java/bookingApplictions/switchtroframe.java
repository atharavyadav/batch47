package bookingApplictions;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;
import Utils.takeScreenshots;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class switchtroframe {
	private static Logger logger = LogManager.getLogger(switchtroframe.class);
	@BeforeMethod
	public void precodition() throws IOException
	{
		 logger.info("execution started");
		 if(ReusableData.Cross_Browser_Type=="chrome") {
			 readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.windowswitch_url);
		 }
		
		 else if(ReusableData.Cross_Browser_Type=="edge")
		 {
			 readBrowserDriver.readbrowser(ReusableData.Edgedriverpath,ReusableData.browsertype_edge,ReusableData.windowswitch_url);
		 }
		logger.info("my url is while execution"+ReusableData.windowswitch_url);
		readBrowserDriver.maximizeBroser();
	}
	@Test(priority = 1)
	public void handleframe() throws IOException, InterruptedException
	{
		
	    seleniumUIActions.switchtoframe();
	   
	    
	}
	
	@AfterMethod
	public void closebrowser() throws IOException, InterruptedException
	{
		Thread.sleep(5000);
	    readBrowserDriver.driver.close();
	}
}
