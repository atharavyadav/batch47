package bookingApplictions;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;
import Utils.takeScreenshots;

public class handlealert {
	@BeforeMethod
	public void precodition() throws IOException
	{readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.alerturl);
    readBrowserDriver.maximizeBroser();
	}
	@Test(priority = 1)
	public void handleAlert() throws IOException
	{
		
		 takeScreenshots.takeUIScreenshot();
	    seleniumUIActions.handleAlert();
	   
	    
	}
	
	@AfterMethod
	public void closebrowser() throws IOException, InterruptedException
	{
		Thread.sleep(5000);
	    readBrowserDriver.driver.close();
	}
}
