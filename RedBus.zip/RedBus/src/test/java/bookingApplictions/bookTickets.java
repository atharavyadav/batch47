package bookingApplictions;
import java.io.IOException;

//Author:neelam
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class bookTickets {
	
	@Test
	public void launchBrowser() throws IOException
	{
		
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.enterVlues();
	}
	@Test
	public void launchBrowser1() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.enterVlues();
	}
	@Test
	public void launchBrowser11() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.enterVlues();
	}
}
