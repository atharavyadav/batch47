package bookingApplictions;

import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;

public class bookTickets {
	
	@Test
	public void launchBrowser()
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	}

}
