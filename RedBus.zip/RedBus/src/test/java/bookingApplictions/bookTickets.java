package bookingApplictions;
import java.io.IOException;

//Author:neelam
import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class bookTickets {
	
	@Test(priority = 1)
	public void launchBrowser() throws IOException
	{
		
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.enterVlues();
	    seleniumUIActions.selectdropdown();
	}
	
	@Test(priority = 2)
	public void clickonHome() throws IOException
	{
		
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.clickHomes();
	}
}