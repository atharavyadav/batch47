package bookingApplictions;

import org.testng.annotations.Test;

import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;

public class registerbooking {
	@Test
	public void launchBrowser()
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype);
	    readBrowserDriver.maximizeBroser();
	}
}
