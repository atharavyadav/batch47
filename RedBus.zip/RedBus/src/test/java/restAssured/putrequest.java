package restAssured;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class putrequest {
	@Test
	public void putrequest()
	{
   Response response = RestAssured.given().headers("content-type","application/json").body("{\r\n"
				+ "   \"name\": \"neelam\",\r\n"
				+ "   \"data\": {\r\n"
				+ "      \"year\": 1993,\r\n"
				+ "      \"price\": 10000,\r\n"
				+ "      \"CPU model\": \"HP\",\r\n"
				+ "      \"Hard disk size\": \"1 TB\"\r\n"
				+ "   }\r\n"
				+ "}")
		.when().put("https://api.restful-api.dev/objects/ff80818192925da70193078db1030142").then().extract().response();
   
      System.out.println(response.statusCode());
      System.out.println(response.body().asString());
     String data =  response.jsonPath().getString("data.year");
     System.out.println(data);
     Assert.assertEquals(data, "1993");
	}
}
