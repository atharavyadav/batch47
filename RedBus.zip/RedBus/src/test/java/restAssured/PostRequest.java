package restAssured;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PostRequest {
	
	@Test
	public void postrequest()
	{
   Response response = RestAssured.given().headers("content-type","application/json").body("{\r\n"
				+ "   \"name\": \"harsdha\",\r\n"
				+ "   \"data\": {\r\n"
				+ "      \"year\": 1993,\r\n"
				+ "      \"price\": 10000,\r\n"
				+ "      \"CPU model\": \"HP\",\r\n"
				+ "      \"Hard disk size\": \"1 TB\"\r\n"
				+ "   }\r\n"
				+ "}")
		.when().post("https://api.restful-api.dev/objects").then().extract().response();
   
      System.out.println(response.statusCode());
      System.out.println(response.body().asString());
	}

}
