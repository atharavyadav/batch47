package restAssured;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetRequest {

	@Test
	public void getrequest()
	{
   Response response = RestAssured.given().headers("content-type","application/json")
		.when().get("https://api.restful-api.dev/objects/ff80818192925da70193078db1030142").then().extract().response();
   
      System.out.println(response.statusCode());
      System.out.println(response.body().asString());
	}
}
